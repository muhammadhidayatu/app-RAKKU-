<?php
session_start();
require 'config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Hapus gambar dulu
    $result = $conn->query("SELECT image_path FROM wardrobe WHERE id = $id");
    $row = $result->fetch_assoc();
    if (file_exists($row['image_path'])) {
        unlink($row['image_path']);
    }

    // Hapus data di database
    $conn->query("DELETE FROM wardrobe WHERE id = $id");
}

header("Location: user.php");
exit;
?>
