<?php
require 'config.php';
// Ubah is_favorite menjadi favorite
$result = $conn->query("SELECT * FROM wardrobe WHERE favorite=1 ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Favorit Saya</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="bg-dark text-white">
  <div class="container mt-5">
    <center>
    <h1 class="mb-4">⭐ Daftar Pakaian Favorit Anda ⭐</h1>
    </center>
    <?php if ($result->num_rows > 0): ?>
      <div class="row">
        <?php while($row = $result->fetch_assoc()): ?>
          <div class="col-md-4 mb-4">
            <div class="card bg-secondary h-100">
              <img src="<?= $row['image_path'] ?>" class="card-img-top" alt="Pakaian">
              <div class="card-body">
                <h5 class="card-title"><?= ucfirst($row['type']) ?> - <?= ucfirst($row['category']) ?></h5>
                <p class="card-text">Rak: <?= $row['rack'] ?><br>Catatan: <?= $row['notes'] ?></p>
              </div>
            </div>
          </div>
        <?php endwhile; ?>
      </div>
    <?php else: ?>
      <div class="alert alert-info">Belum ada pakaian favorit.</div>
    <?php endif; ?>
    <a href="user.php" class="btn btn-warning mt-4">Kembali</a>
  </div>
</body>
</html>