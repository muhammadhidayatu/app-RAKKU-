<?php
// image_functions.php
require 'vendor/autoload.php';
use ColorThief\ColorThief;

function ekstrakFiturGambar($filePath) {
    // Validasi file
    if (!file_exists($filePath)) {
        return ['error' => 'File tidak ditemukan'];
    }

    // Cek ekstensi file
    $allowedTypes = ['image/jpeg', 'image/png'];
    $mime = mime_content_type($filePath);
    
    if (!in_array($mime, $allowedTypes)) {
        return ['error' => 'Format file tidak didukung'];
    }

    try {
        // Ekstrak warna dominan
        $dominantColor = ColorThief::getColor($filePath);
        $warna = implode(',', $dominantColor);
        
        return [
            'warna' => $warna,
            'tekstur' => 'standar', // Di real case bisa pakai analisis tekstur
            'bentuk' => 'standar'
        ];
    } catch (Exception $e) {
        return ['error' => 'Gagal memproses gambar: ' . $e->getMessage()];
    }
}

function simpanFiturKeDatabase($conn, $gambarPath, $fitur) {
    $sql = "INSERT INTO pakaian (gambar_path, fitur_warna, fitur_tekstur, fitur_bentuk)
            VALUES (?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $gambarPath, $fitur['warna'], $fitur['tekstur'], $fitur['bentuk']);
    
    return $stmt->execute();
}
?>