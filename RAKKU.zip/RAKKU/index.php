<!DOCTYPE html>
<?php
require 'config.php';
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RAKKU</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/styles.css">
    <style>
        /* Transition effects */
        body, .navbar, .card-header, .btn-warning {
            transition: background-color 0.5s ease, color 0.3s ease;
        }
        
        /* Dark mode styles */
        body.dark-mode {
            background-color: #121212;
            color: #f8f9fa;
        }
        
        /* Light mode (default) - Blue elements */
        .navbar {
            background-color: #0d6efd !important; /* Blue in light mode */
        }
        
        .card-header {
            background-color: #0d6efd !important; /* Blue in light mode */
            color: #f8f9fa !important;
        }
        
        .btn-warning {
            background-color: #0d6efd;
            border-color: #0d6efd;
            color: #f8f9fa;
        }
        
        /* Dark mode - Yellow elements */
        .dark-mode .navbar {
            background-color: #ffc107 !important; /* Yellow in dark mode */
        }
        
        .dark-mode .card-header {
            background-color: #ffc107 !important; /* Yellow in dark mode */
            color: #212529 !important;
        }
        
        .dark-mode .btn-warning {
            background-color: #ffc107;
            border-color: #ffc107;
            color: #212529;
        }
        
        /* Common dark mode styles */
        .dark-mode .card {
            background-color: #1e1e1e;
            color: #f8f9fa;
        }
        
        .dark-mode .form-control, 
        .dark-mode .form-select,
        .dark-mode .form-check-input,
        .dark-mode .form-check-label,
        .dark-mode textarea {
            background-color: #2d2d2d;
            color: #f8f9fa;
            border-color: #444;
        }
        
        .dark-mode .form-control:focus, 
        .dark-mode .form-select:focus {
            background-color: #3d3d3d;
            color: #f8f9fa;
            border-color: #ffc107;
            box-shadow: 0 0 0 0.25rem rgba(255, 193, 7, 0.25);
        }
        
        /* Navbar text color adjustment */
        .navbar-brand.text-dark {
            transition: color 0.3s ease;
        }
        .dark-mode .navbar-brand.text-dark {
            color: #212529 !important;
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">

<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand text-dark" href="#">RAKKU</a>
    <!-- Dark Mode Toggle with sun/moon icons -->
    <button class="btn btn-outline-dark rounded-pill px-3 ms-3" id="darkModeToggle">
        <i class="fas fa-sun"></i>
        <i class="fas fa-moon d-none"></i>
    </button>
  </div>
</nav>


    <!-- Main Content -->
    <main class="container my-5 flex-grow-1">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <!-- Form Upload -->
<div class="card shadow">
    <div class="card-header">
        <h3 class="card-title text-center">Tambah Rak Baju atau Celana</h3>
    </div>
    <div class="card-body">
        <form action="process.php" method="POST" enctype="multipart/form-data">
            <!-- Tambahan Hidden Input -->
    <input type="hidden" name="action" value="tambah">
            <!-- Input Gambar -->
            <div class="mb-3">
                <label for="image" class="form-label">Upload Gambar Baju atau Celana</label>
                <input type="file" class="form-control" id="image" name="image" accept="image/*" required>
            </div>

            <!-- Pilihan Rak -->
            <div class="mb-3">
                <label class="form-label">Jenis:</label>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="type" id="baju" value="baju" checked>
                    <label class="form-check-label" for="baju">Baju</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="type" id="celana" value="celana">
                    <label class="form-check-label" for="celana">Celana</label>
                </div>
            </div>

            <!-- Input Kategori -->
            <div class="mb-3">
                <label for="category" class="form-label">Kategori Pakaian:</label>
                <select class="form-select" id="category" name="category" required>
                    <option value="kasual">Kasual</option>
                    <option value="formal">Formal</option>
                    <option value="olahraga">Olahraga</option>
                </select>
            </div>

            <!-- Input Rak -->
            <div class="mb-3">
                <label for="rack" class="form-label">Lokasi Rak:</label>
                <select class="form-select" id="rack" name="rack" required>
                    <option value="A">Rak A</option>
                    <option value="B">Rak B</option>
                    <option value="C">Rak C</option>
                    <option value="C">Rak D</option>
                </select>
            </div>

            <!-- Input Catatan -->
            <div class="mb-3">
                <label for="notes" class="form-label">Catatan:</label>
                <textarea class="form-control" id="notes" name="notes" rows="3"></textarea>
            </div>

            <!-- Tombol Submit -->
            <button type="submit" class="btn btn-warning w-100">Tambah</button>
        </form>

        <!-- Notifikasi -->
        <?php if (isset($_GET['status'])): ?>
            <div class="alert alert-<?php echo $_GET['status']; ?> mt-4">
                <?php echo htmlspecialchars($_GET['message']); ?>
            </div>
        <?php endif; ?>
    </div>
</div>

</div> <!-- Tombol di bawah riwayat pencarian -->
 <div class="d-flex justify-content-center gap-3 mt-4">
    <a href="user.php" class="btn btn-warning">User</a>
</div>
    </main>

    <!-- Bootstrap JS (opsional) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Enhanced Dark Mode Toggle Script -->
    <script>
        const darkModeToggle = document.getElementById('darkModeToggle');
        const sunIcon = darkModeToggle.querySelector('.fa-sun');
        const moonIcon = darkModeToggle.querySelector('.fa-moon');
        
        // Check for saved dark mode preference
        if (localStorage.getItem('darkMode') === 'enabled') {
            document.body.classList.add('dark-mode');
            sunIcon.classList.add('d-none');
            moonIcon.classList.remove('d-none');
        } else {
            sunIcon.classList.remove('d-none');
            moonIcon.classList.add('d-none');
        }
        
        darkModeToggle.addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
            
            // Toggle icons
            sunIcon.classList.toggle('d-none');
            moonIcon.classList.toggle('d-none');
            
            // Save preference
            if (document.body.classList.contains('dark-mode')) {
                localStorage.setItem('darkMode', 'enabled');
            } else {
                localStorage.setItem('darkMode', 'disabled');
            }
        });
    </script>
</body>
</html>