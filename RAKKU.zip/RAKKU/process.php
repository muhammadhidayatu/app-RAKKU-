<?php
require 'config.php';

// Error reporting untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

$action = $_POST['action'] ?? null;

if ($action === 'tambah') {
    // Validasi input
    $required = ['type', 'category', 'rack'];
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            header("Location: index.php?status=error&message=Field $field harus diisi");
            exit;
        }
    }

    // Validasi file upload
    if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        header("Location: index.php?status=error&message=Gambar harus diupload");
        exit;
    }

    // Validasi ekstensi file
    $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];
    $fileExtension = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
    if (!in_array($fileExtension, $allowedExtensions)) {
        header("Location: index.php?status=error&message=Hanya file gambar (JPG/PNG/GIF) yang diperbolehkan");
        exit;
    }

    // Validasi ukuran file (max 5MB)
    if ($_FILES["image"]["size"] > 5000000) {
        header("Location: index.php?status=error&message=Ukuran file terlalu besar (maks 5MB)");
        exit;
    }

    // Buat folder uploads jika belum ada
    if (!file_exists('uploads')) {
        mkdir('uploads', 0755, true);
    }

    // Generate nama file unik
    $uniqueFilename = uniqid() . '_' . bin2hex(random_bytes(8)) . '.' . $fileExtension;
    $targetPath = "uploads/" . $uniqueFilename;

    // Pindahkan file
    if (!move_uploaded_file($_FILES["image"]["tmp_name"], $targetPath)) {
        header("Location: index.php?status=error&message=Gagal menyimpan gambar");
        exit;
    }

    // Generate hash
    $hash = md5_file($targetPath);

    // Simpan ke database
    try {
        $stmt = $conn->prepare("INSERT INTO wardrobe (type, category, rack, notes, image_path, image_hash) VALUES (?, ?, ?, ?, ?, ?)");
        
        // Pisahkan variabel untuk binding
        $type = $_POST['type'];
        $category = $_POST['category'];
        $rack = $_POST['rack'];
        $notes = $_POST['notes'] ?? '';
        
        $stmt->bind_param("ssssss", $type, $category, $rack, $notes, $targetPath, $hash);
        
        if (!$stmt->execute()) {
            unlink($targetPath);
            throw new Exception("Gagal menyimpan ke database: " . $stmt->error);
        }

        header("Location: index.php?status=success&message=Data berhasil ditambahkan");
        exit;
    } catch (Exception $e) {
        header("Location: index.php?status=error&message=" . urlencode($e->getMessage()));
        exit;
    }
} 
elseif ($action === 'cari') {
    // Validasi file upload
    if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        header("Location: user.php?status=error&message=Silakan upload gambar terlebih dahulu");
        exit;
    }

    // Validasi ekstensi file
    $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];
    $fileExtension = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
    if (!in_array($fileExtension, $allowedExtensions)) {
        header("Location: user.php?status=invalid&message=Format file tidak valid (hanya JPG/JPEG/PNG/GIF)");
        exit;
    }

    // Validasi tipe MIME file
    $allowedMimeTypes = ['image/jpeg', 'image/png', 'image/gif'];
    $fileInfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($fileInfo, $_FILES['image']['tmp_name']);
    finfo_close($fileInfo);

    if (!in_array($mimeType, $allowedMimeTypes)) {
        header("Location: user.php?status=invalid&message=Tipe file tidak valid");
        exit;
    }

    // Generate hash dari file
    $searchHash = md5_file($_FILES['image']['tmp_name']);
    
    // Debug: Catat hash yang dicari
    error_log("Mencari gambar dengan hash: " . $searchHash);

    // Cari di database
    $stmt = $conn->prepare("SELECT * FROM wardrobe WHERE image_hash = ?");
    $stmt->bind_param("s", $searchHash);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
        
        // Debug: Catat data yang ditemukan
        error_log("Data ditemukan: " . print_r($data, true));
        
        // Redirect dengan data yang ditemukan
        $queryParams = [
            'status' => 'found',
            'id' => $data['id'],
            'type' => $data['type'],
            'category' => $data['category'],
            'rack' => $data['rack'],
            'notes' => $data['notes'],
            'image' => $data['image_path'],
            'favorite' => $data['favorite']
        ];
        
        header("Location: user.php?" . http_build_query($queryParams));
        exit;
    } else {
        // Debug: Catat ketika tidak ditemukan
        error_log("Data tidak ditemukan untuk hash: " . $searchHash);
        
        header("Location: user.php?status=notfound&message=Data tidak ditemukan");
        exit;
    }
} 
else {
    header("Location: user.php?status=invalid&message=Aksi tidak valid");
    exit;
}