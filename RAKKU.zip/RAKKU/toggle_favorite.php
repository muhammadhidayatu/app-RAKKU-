<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = intval($_POST['id']);
    
    // Tambahkan validasi sederhana
    if ($id <= 0) {
        header("Location: user.php?status=invalid_id");
        exit;
    }
    
    // Gunakan prepared statement untuk keamanan
    $stmt = $conn->prepare("SELECT favorite FROM wardrobe WHERE id = ?");
    if (!$stmt) {
        // Error pada prepare statement
        error_log("Database error: " . $conn->error);
        header("Location: user.php?status=db_error");
        exit;
    }
    
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result && $row = $result->fetch_assoc()) {
        // Pastikan kolom favorite ada
        if (!isset($row['favorite'])) {
            error_log("Column 'favorite' not found in result");
            header("Location: user.php?status=column_error");
            exit;
        }
        
        $current = $row['favorite'];
        $new = $current ? 0 : 1;
        
        // Update status favorite dengan prepared statement
        $update = $conn->prepare("UPDATE wardrobe SET favorite = ? WHERE id = ?");
        $update->bind_param("ii", $new, $id);
        $update->execute();
        
        // Redirect kembali ke user.php dengan parameter terbaru
        $data_stmt = $conn->prepare("SELECT * FROM wardrobe WHERE id = ?");
        $data_stmt->bind_param("i", $id);
        $data_stmt->execute();
        $data_result = $data_stmt->get_result();
        $data = $data_result->fetch_assoc();
        
        $params = http_build_query([
            'status'   => 'found',
            'id'       => $data['id'],
            'type'     => $data['type'],
            'category' => $data['category'],
            'rack'     => $data['rack'],
            'notes'    => $data['notes'],
            'favorite' => $data['favorite'],
            'image'    => $data['image_path']
        ]);
        
        header("Location: user.php?$params");
        exit;
    } else {
        header("Location: user.php?status=not_found");
        exit;
    }
} else {
    header("Location: user.php?status=invalid");
    exit;
}