<?php
require 'vendor/autoload.php';
use ColorThief\ColorThief;

function ekstrakFiturGambar($filePath) {
    // Ekstrak warna dominan
    $dominantColor = ColorThief::getColor($filePath);
    $warna = implode(',', $dominantColor);
    
    // Ekstrak tekstur sederhana (contoh: brightness)
    $image = imagecreatefromjpeg($filePath);
    $brightness = imagefilter($image, IMG_FILTER_BRIGHTNESS, 0);
    imagedestroy($image);
    
    return [
        'warna' => $warna,
        'tekstur' => $brightness > 0 ? 'terang' : 'gelap',
        'bentuk' => 'standar' // Di real case bisa pakai OpenCV
    ];
}

// Contoh penggunaan
$fitur = ekstrakFiturGambar('uploads/gambar_contoh.jpg');
?>