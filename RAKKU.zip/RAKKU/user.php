<?php
require 'config.php';

$result = $conn->query("SELECT * FROM wardrobe ORDER BY id DESC");

$totalBaju   = $conn->query("SELECT COUNT(*) AS total FROM wardrobe WHERE type='baju'")->fetch_assoc()['total'];
$totalCelana = $conn->query("SELECT COUNT(*) AS total FROM wardrobe WHERE type='celana'")->fetch_assoc()['total'];

$kategoriKasual   = $conn->query("SELECT COUNT(*) AS total FROM wardrobe WHERE category='kasual'")->fetch_assoc()['total'];
$kategoriFormal   = $conn->query("SELECT COUNT(*) AS total FROM wardrobe WHERE category='formal'")->fetch_assoc()['total'];
$kategoriOlahraga = $conn->query("SELECT COUNT(*) AS total FROM wardrobe WHERE category='olahraga'")->fetch_assoc()['total'];

$rakA = $conn->query("SELECT COUNT(*) AS total FROM wardrobe WHERE rack='A'")->fetch_assoc()['total'];
$rakB = $conn->query("SELECT COUNT(*) AS total FROM wardrobe WHERE rack='B'")->fetch_assoc()['total'];
$rakC = $conn->query("SELECT COUNT(*) AS total FROM wardrobe WHERE rack='C'")->fetch_assoc()['total'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>RAKKU - Cari Rak Pakaian</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <link rel="stylesheet" href="css/user.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body class="bg-dark text-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-warning sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand text-dark" href="#">RAKKU</a>
  </div>
</nav>

<div class="container mt-5">
  <div class="form-upload">
    <h3 class="mb-4">Upload Gambar Pakaian</h3>
    <form action="process.php" method="POST" enctype="multipart/form-data">
      <a href="favorites.php" class="btn btn-outline-light mb-3">⭐ Lihat Pakaian Favorit</a>
      <div class="form-group">
        <label for="image">Silakan Upload gambar:</label>
        <input type="file" class="form-control" id="image" name="image" accept="image/*" required>
      </div>
      <input type="hidden" name="action" value="cari">
      <button type="submit" class="btn btn-warning text-dark w-100">Cari</button>
    </form>
  </div>

  <?php if (isset($_GET['status'])): ?>
    <div class="result-card mt-4">
      <?php if ($_GET['status'] === 'found'): ?>
        <h4>Hasil Pencarian:</h4>
        <?php if (isset($_GET['status']) && $_GET['status'] === 'found' && isset($_GET['id'])): ?>
    <?php $isFav = isset($_GET['favorite']) && $_GET['favorite'] == 1; ?>
    <form action="toggle_favorite.php" method="POST" style="margin-top: 10px;">
        <input type="hidden" name="id" value="<?= htmlspecialchars($_GET['id']) ?>">
        <button type="submit" class="btn btn-warning">
            <?= $isFav ? '★ Favorit (Klik untuk Hapus)' : '☆ Tambah ke Favorit' ?>
        </button>
        <br>
        <br>
    </form>
<?php endif; ?>


        <div class="d-flex flex-row align-items-start flex-wrap" style="gap: 20px;">
          <div style="flex: 0 0 auto; max-width: 150px;">
          <img src="<?= htmlspecialchars($_GET['image']) ?>" alt="Gambar Pakaian" class="img-fluid rounded" onerror="this.src='path/to/default-image.jpg'">
          </div>
          <div style="flex: 1 1 auto; padding-left: 10px;">
            <ul class="list-group list-group-flush">
              <li class="list-group-item bg-transparent text-light border-0 px-0 mb-1">
                <strong>Jenis:</strong> <?= htmlspecialchars($_GET['type']) ?>
              </li>
              <li class="list-group-item bg-transparent text-light border-0 px-0 mb-1">
                <strong>Kategori:</strong> <?= htmlspecialchars($_GET['category']) ?>
              </li>
              <li class="list-group-item bg-transparent text-light border-0 px-0 mb-1">
                <strong>Rak:</strong> <?= htmlspecialchars($_GET['rack']) ?>
              </li>
              <li class="list-group-item bg-transparent text-light border-0 px-0">
                <strong>Catatan:</strong> <?= htmlspecialchars($_GET['notes']) ?>
              </li>
            </ul>
          </div>
        </div>
      <?php elseif ($_GET['status'] === 'notfound'): ?>
        <div class="alert alert-danger mt-3">❌ Data tidak ditemukan!</div>
      <?php elseif ($_GET['status'] === 'invalid'): ?>
        <div class="alert alert-warning mt-3">⚠️ Format file tidak valid!</div>
      <?php elseif ($_GET['status'] === 'error'): ?>
        <div class="alert alert-danger mt-3">❗ Silakan upload gambar terlebih dahulu!</div>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <a class="btn btn-warning text-dark mt-4" href="index.php">Kembali</a>
</div>

<div class="container mt-4 fade-in">
  <div class="card bg-dark text-white shadow mb-4 stat-card">
    <div class="card-header bg-warning text-dark text-center">
      <h5>📈 Statistik Pakaian</h5>
    </div>
    <div class="card-body">
      <canvas id="wardrobeChart" height="200"></canvas>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  const ctx = document.getElementById('wardrobeChart').getContext('2d');
  const wardrobeChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Baju', 'Celana', 'Kasual', 'Formal', 'Olahraga', 'Rak A', 'Rak B', 'Rak C'],
      datasets: [{
        label: 'Jumlah Item',
        data: [<?= $totalBaju ?>, <?= $totalCelana ?>, <?= $kategoriKasual ?>, <?= $kategoriFormal ?>, <?= $kategoriOlahraga ?>, <?= $rakA ?>, <?= $rakB ?>, <?= $rakC ?>],
        backgroundColor: [
          'rgba(255, 99, 132, 0.7)',
          'rgba(54, 162, 235, 0.7)',
          'rgba(255, 206, 86, 0.7)',
          'rgba(75, 192, 192, 0.7)',
          'rgba(153, 102, 255, 0.7)',
          'rgba(255, 159, 64, 0.7)',
          'rgba(199, 199, 199, 0.7)',
          'rgba(83, 102, 255, 0.7)'
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)',
          'rgba(255, 159, 64, 1)',
          'rgba(199, 199, 199, 1)',
          'rgba(83, 102, 255, 1)'
        ],
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: { beginAtZero: true }
      }
    }
  });

  $('#favBtn').click(function() {
    const form = $('#favForm');
    $.post('toggle_favorite.php', form.serialize(), function(response) {
      const res = JSON.parse(response);
      if (res.status === 'success') location.reload();
    });
  });

  $(window).scroll(function() {
    $('.navbar').toggleClass('sticky-scroll', $(this).scrollTop() > 50);
  });
</script>

</body>
</html>
